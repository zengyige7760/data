import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog
import random

class ChatClient:
    def __init__(self, root):
        self.root = root
        self.root.title("聊天室客户端")
        self.root.geometry("700x600")
        self.root.resizable(True, True)

        # 设置字体
        self.font = ('SimHei', 10)

        # 连接服务器
        self.server_ip = simpledialog.askstring("服务器连接", "请输入服务器IP地址:", parent=self.root)
        if not self.server_ip:
            self.root.destroy()
            return

        self.chat_port = 9999
        self.nickname = simpledialog.askstring("用户信息", "请输入你的昵称:", parent=self.root)
        if not self.nickname:
            self.nickname = "匿名用户"

        # 创建聊天socket
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.client.connect((self.server_ip, self.chat_port))
            self.client.send(self.nickname.encode('utf-8'))
        except Exception as e:
            messagebox.showerror("连接错误", f"无法连接到服务器: {e}")
            self.root.destroy()
            return

        # 创建UI
        self.create_widgets()

        # 启动接收消息线程
        self.receive_thread = threading.Thread(target=self.receive_messages)
        self.receive_thread.daemon = True
        self.receive_thread.start()

        # 窗口关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def create_widgets(self):
        # 主框架
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 聊天历史显示区域
        self.chat_history = scrolledtext.ScrolledText(main_frame, wrap=tk.WORD, font=self.font)
        self.chat_history.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.chat_history.config(state=tk.DISABLED)

        # 分隔线
        separator = tk.Frame(main_frame, height=2, bd=1, relief=tk.SUNKEN)
        separator.pack(fill=tk.X, padx=5, pady=5)

        # 底部功能区
        bottom_frame = tk.Frame(main_frame)
        bottom_frame.pack(fill=tk.X, padx=5, pady=5)

        # 输入区域
        input_frame = tk.Frame(bottom_frame)
        input_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        self.message_entry = tk.Entry(input_frame, font=self.font)
        self.message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.message_entry.focus_set()
        self.message_entry.bind("<Return>", self.send_message)

        self.send_button = tk.Button(input_frame, text="发送", font=self.font, command=self.send_message)
        self.send_button.pack(side=tk.RIGHT, padx=5)

    def receive_messages(self):
        while True:
            try:
                message = self.client.recv(1024).decode('utf-8')
                # 普通消息
                self.update_chat_history(message)
            except Exception as e:
                print(f"接收消息错误: {e}")
                self.client.close()
                self.update_chat_history("与服务器的连接已断开")
                break

    def send_message(self, event=None):
        message = self.message_entry.get().strip()
        if message:
            if len(message) >= 2:
                # 替换随机五个字
                replace_chars = "浊音"
                indices = random.sample(range(len(message)), 2)
                indices.sort()
                new_message = list(message)
                for i, idx in enumerate(indices):
                    new_message[idx] = replace_chars[i]
                message = ''.join(new_message)
            try:
                self.client.send(f'{self.nickname}: {message}'.encode('utf-8'))
                self.message_entry.delete(0, tk.END)
            except Exception as e:
                self.update_chat_history(f"发送消息失败: {e}")

    def update_chat_history(self, message):
        self.chat_history.config(state=tk.NORMAL)
        self.chat_history.insert(tk.END, message + "\n")
        self.chat_history.see(tk.END)
        self.chat_history.config(state=tk.DISABLED)

    def on_closing(self):
        if messagebox.askyesno("退出", "确定要退出聊天室吗?"):
            try:
                self.client.send(f'SYSTEM: {self.nickname} 离开了聊天室'.encode('utf-8'))
                self.client.close()
            except:
                pass
            self.root.destroy()


if __name__ == "__main__":
    print("开发：豆包 调试：汪子翔 改进：曾一格/腾泽同")
    print("此程序为端午整活版本")
    print("@整活三缺一 请勿二次分发！")
    print("\n")
    root = tk.Tk()
    # 确保中文显示正常
    try:
        root.option_add("*Font", "SimHei 10")
    except:
        pass
    app = ChatClient(root)
    root.mainloop()
