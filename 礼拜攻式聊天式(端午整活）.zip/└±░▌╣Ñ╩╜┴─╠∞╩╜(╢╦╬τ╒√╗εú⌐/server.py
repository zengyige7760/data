import socket
import threading

# 获取本地IP地址
def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except:
        return '127.0.0.1'

# 服务器配置
HOST = get_local_ip()
PORT = 9999
print("开发：豆包 调试：汪子翔 改进：曾一格/腾泽同")
print("此程序为端午整活版本")
print("@整活三缺一 请勿二次分发！")
print("\n")
print(f"服务器IP地址: {HOST}")
print(f"聊天端口: {PORT}")

# 创建聊天socket
chat_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
chat_server.bind((HOST, PORT))
chat_server.listen()

# 存储客户端和对应的昵称
clients = []
nicknames = []

# 广播消息给所有客户端
def broadcast(message):
    for client in clients:
        client.send(message)

# 处理客户端连接
def handle(client):
    while True:
        try:
            # 接收客户端消息
            message = client.recv(1024)
            # 普通消息
            broadcast(message)
        except:
            # 处理客户端断开连接的情况
            index = clients.index(client)
            clients.remove(client)
            client.close()
            nickname = nicknames[index]
            nicknames.remove(nickname)
            broadcast(f'SYSTEM: {nickname} 离开了聊天室'.encode('utf-8'))
            break

# 接收客户端连接
def receive():
    while True:
        client, address = chat_server.accept()
        print(f'聊天连接地址: {str(address)}')

        # 获取客户端昵称
        client.send('NICK'.encode('utf-8'))
        nickname = client.recv(1024).decode('utf-8')
        nicknames.append(nickname)
        clients.append(client)

        print(f'用户 {nickname} 已连接!')
        broadcast(f'SYSTEM: {nickname} 加入了聊天室'.encode('utf-8'))
        client.send('连接成功!'.encode('utf-8'))

        # 为每个客户端创建一个线程来处理消息
        thread = threading.Thread(target=handle, args=(client,))
        thread.start()

# 启动聊天线程
print("服务器正在监听...")
chat_thread = threading.Thread(target=receive)
chat_thread.start()
